Files included in this delivery package:

Presentation PDFs:
01AzureGovernanceEssentials-Kickoff-Governance
02AzureGovernanceEssentials-OrgAlignment
03AzureGovernanceEssentials-ResourceManagement
04AzureGovernanceEssentials-AzurePolicies
05AzureGovernanceEssentials-NamingANDTags
06AzureGovernanceEssentials-Monitoring
08AzureGovernanceEssentials-Closeout

Engagement files:
Azure Governance Essentials - Governance Roles Mapping.xlsx
  Sheets for list governance role assignments
Azure Governance Essentials Survey.xlsx 
  List of questions to be answered during the engagement and used to assess governance next steps
Azure Governance Organization Charter.docx
  Example charter document to authorize governance body and understand roles/tacks
BPA-Azure-Hierarchy.vsxd
  Visio file with governance body, processes, and backlog examples
CAF Readiness Naming and Tagging tracking template.xlsx
  Workbook list naming convention and resource tagging examples/tracking
CAF Risks and Policies.xlsx
  Workbook listing example cloud risks and policies following new CAF govern model.
Legacy-Azure-Risks.xlsx
  Workbook listing example cloud risks and policies following legacy CAF govern disciplines.